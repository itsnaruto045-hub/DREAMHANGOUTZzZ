import mongoose from "mongoose";

const mongoUri = process.env.MONGODB_URI || "mongodb://localhost:27017/dreamhangout";

export async function connectDB() {
  try {
    await mongoose.connect(mongoUri);
    console.log("Connected to MongoDB");
  } catch (error) {
    console.warn("Warning: MongoDB connection failed. Using in-memory storage.");
    console.warn("To use MongoDB, provide a valid MONGODB_URI environment variable.");
    // Continue without MongoDB - models will still work with in-memory operations
  }
}

// Define schemas
const userSchema = new mongoose.Schema({
  username: { type: String, required: true, unique: true },
  password: { type: String, required: true },
  role: { type: String, default: "user" },
  credits: { type: Number, default: 0 },
  createdAt: { type: Date, default: Date.now },
});

const itemSchema = new mongoose.Schema({
  title: { type: String, required: true },
  description: { type: String, required: true },
  price: { type: Number, required: true },
  type: { type: String, required: true },
  content: String,
  createdAt: { type: Date, default: Date.now },
});

const itemContentSchema = new mongoose.Schema({
  itemId: { type: mongoose.Schema.Types.ObjectId, required: true },
  pageNumber: { type: Number, required: true },
  content: { type: String, required: true },
});

const purchaseSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, required: true },
  itemId: { type: mongoose.Schema.Types.ObjectId, required: true },
  purchasedAt: { type: Date, default: Date.now },
  contentDelivered: String,
});

const transactionSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, required: true },
  transactionId: { type: String, required: true },
  amount: { type: Number, required: true },
  status: { type: String, default: "pending" },
  createdAt: { type: Date, default: Date.now },
});

const ticketSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, required: true },
  subject: { type: String, required: true },
  message: { type: String, required: true },
  status: { type: String, default: "open" },
  reply: String,
  createdAt: { type: Date, default: Date.now },
});

const redeemCodeSchema = new mongoose.Schema({
  code: { type: String, required: true, unique: true },
  value: { type: Number, required: true },
  isUsed: { type: Boolean, default: false },
  usedBy: mongoose.Schema.Types.ObjectId,
  createdAt: { type: Date, default: Date.now },
});

// Export models
export const User = mongoose.model("User", userSchema);
export const Item = mongoose.model("Item", itemSchema);
export const ItemContent = mongoose.model("ItemContent", itemContentSchema);
export const Purchase = mongoose.model("Purchase", purchaseSchema);
export const Transaction = mongoose.model("Transaction", transactionSchema);
export const Ticket = mongoose.model("Ticket", ticketSchema);
export const RedeemCode = mongoose.model("RedeemCode", redeemCodeSchema);
