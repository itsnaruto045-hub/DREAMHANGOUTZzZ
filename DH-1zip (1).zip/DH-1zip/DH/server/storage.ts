import { randomBytes } from "crypto";
import { 
  User as UserType, 
  Item as ItemType, 
  Transaction as TransactionType, 
  Ticket as TicketType, 
  InsertUser, 
  InsertItem, 
  InsertTransaction, 
  InsertTicket 
} from "@shared/schema";
import { User, Item, ItemContent, Purchase, Transaction, Ticket, RedeemCode } from "./db";

export interface IStorage {
  getUser(id: string | number): Promise<UserType | undefined>;
  getUserByUsername(username: string): Promise<UserType | undefined>;
  createUser(user: InsertUser): Promise<UserType>;
  updateUserCredits(id: string, credits: number): Promise<UserType>;
  getUserCount(): Promise<number>;
  
  getItems(): Promise<ItemType[]>;
  getItem(id: string | number): Promise<ItemType | undefined>;
  createItem(item: InsertItem & { contents?: string[] }): Promise<ItemType>;
  deleteItem(id: string | number): Promise<void>;
  
  getTransactions(): Promise<TransactionType[]>;
  createTransaction(transaction: InsertTransaction & { userId: string }): Promise<TransactionType>;
  updateTransactionStatus(id: string | number, status: string): Promise<TransactionType>;
  updateTransactionAmount(id: string | number, amount: number): Promise<TransactionType>;
  
  getTickets(): Promise<TicketType[]>;
  createTicket(ticket: InsertTicket & { userId: string }): Promise<TicketType>;
  updateTicketReply(id: string | number, reply: string): Promise<TicketType>;
  
  createPurchase(userId: string, itemId: string, content: string): Promise<void>;
  
  getRedeemCode(code: string): Promise<{ id: string; value: number; isUsed: boolean | null } | undefined>;
  markRedeemCodeUsed(id: string, userId: string): Promise<void>;
  generateRedeemCodes(value: number, count: number): Promise<{ id: string; code: string; value: number }[]>;
}

function toMongoId(id: string | number): string {
  return String(id);
}

export class DatabaseStorage implements IStorage {
  async getUser(id: string | number): Promise<UserType | undefined> {
    try {
      const user = await User.findById(toMongoId(id));
      return user ? (user.toObject() as any) : undefined;
    } catch {
      return undefined;
    }
  }

  async getUserByUsername(username: string): Promise<UserType | undefined> {
    const user = await User.findOne({ username });
    return user ? (user.toObject() as any) : undefined;
  }

  async createUser(insertUser: InsertUser): Promise<UserType> {
    const user = new User(insertUser);
    await user.save();
    return user.toObject() as any;
  }

  async getUserCount(): Promise<number> {
    return await User.countDocuments();
  }

  async updateUserCredits(id: string, credits: number): Promise<UserType> {
    const user = await User.findByIdAndUpdate(
      toMongoId(id),
      { credits },
      { new: true }
    );
    return user?.toObject() as any;
  }

  async getItems(): Promise<ItemType[]> {
    const items = await Item.find();
    return items.map(item => item.toObject() as any);
  }

  async getItem(id: string | number): Promise<ItemType | undefined> {
    try {
      const item = await Item.findById(toMongoId(id));
      return item ? (item.toObject() as any) : undefined;
    } catch {
      return undefined;
    }
  }

  async createItem(insertItem: InsertItem & { contents?: string[] }): Promise<ItemType> {
    const item = new Item(insertItem);
    await item.save();
    
    if (insertItem.type === 'sequential' && insertItem.contents) {
      await ItemContent.insertMany(
        insertItem.contents.map((content, index) => ({
          itemId: item._id,
          pageNumber: index + 1,
          content,
        }))
      );
    }
    
    return item.toObject() as any;
  }

  async getTransactions(): Promise<TransactionType[]> {
    const txs = await Transaction.find();
    return txs.map(tx => tx.toObject() as any);
  }

  async createTransaction(transaction: InsertTransaction & { userId: string }): Promise<TransactionType> {
    const tx = new Transaction(transaction);
    await tx.save();
    return tx.toObject() as any;
  }

  async updateTransactionStatus(id: string | number, status: string): Promise<TransactionType> {
    const tx = await Transaction.findByIdAndUpdate(
      toMongoId(id),
      { status },
      { new: true }
    );
    return tx?.toObject() as any;
  }

  async updateTransactionAmount(id: string | number, amount: number): Promise<TransactionType> {
    const tx = await Transaction.findByIdAndUpdate(
      toMongoId(id),
      { amount },
      { new: true }
    );
    return tx?.toObject() as any;
  }

  async getTickets(): Promise<TicketType[]> {
    const tickets = await Ticket.find();
    return tickets.map(t => t.toObject() as any);
  }

  async createTicket(ticket: InsertTicket & { userId: string }): Promise<TicketType> {
    const t = new Ticket(ticket);
    await t.save();
    return t.toObject() as any;
  }

  async updateTicketReply(id: string | number, reply: string): Promise<TicketType> {
    const t = await Ticket.findByIdAndUpdate(
      toMongoId(id),
      { reply, status: 'closed' },
      { new: true }
    );
    return t?.toObject() as any;
  }

  async createPurchase(userId: string, itemId: string, content: string): Promise<void> {
    const purchase = new Purchase({
      userId: toMongoId(userId),
      itemId: toMongoId(itemId),
      contentDelivered: content,
    });
    await purchase.save();
  }

  async getRedeemCode(code: string) {
    const rc = await RedeemCode.findOne({ code });
    return rc ? { id: String(rc._id), value: rc.value, isUsed: rc.isUsed } : undefined;
  }

  async markRedeemCodeUsed(id: string, userId: string): Promise<void> {
    await RedeemCode.findByIdAndUpdate(
      toMongoId(id),
      { isUsed: true, usedBy: toMongoId(userId) }
    );
  }

  async deleteItem(id: string | number): Promise<void> {
    await Item.findByIdAndDelete(toMongoId(id));
    await ItemContent.deleteMany({ itemId: toMongoId(id) });
  }

  async generateRedeemCodes(value: number, count: number): Promise<{ id: string; code: string; value: number }[]> {
    const codes = Array.from({ length: count }, () => {
      const randomCode = randomBytes(8).toString('hex').toUpperCase();
      return { code: randomCode, value };
    });
    
    const result = await RedeemCode.insertMany(codes);
    return result.map(r => ({ id: String(r._id), code: r.code, value: r.value }));
  }
}

export const storage = new DatabaseStorage();
